/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import Login.LoginPage;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.sql.ResultSet;
import javax.swing.JTextField;
import static pso.PSO.finalUser;

/**
 *
 * @author test
 */
public class APackageRenderer {

    APackages Apcks;

    public APackageRenderer(APackages Apcks) {
        this.Apcks = Apcks;
        message.setFont(new Font("Serif", Font.ITALIC, 24));
        message.setPreferredSize(new Dimension(770, 40));
        message.setEditable(false);
    }
    public javax.swing.JTextField message = new javax.swing.JTextField();

    /*
     * Getting Packages  
     * 
     */
    public void getpkgs(String search) {
        try {
            if (search.equals("")) {
                this.Apcks.pnlpackages.removeAll();
                String query = "select * from packages";
                ResultSet rs = LoginPage.db.getResultSet(query);
                if (this.Apcks != null) {
                    while (rs.next()) {
                        int Pid = rs.getInt("Pid");
                        String PName = rs.getString("PName");
                        String origin = rs.getString("origin");
                        String destination = rs.getString("destination");
                        String departure = rs.getString("departure");
                        String arrival = rs.getString("arrival");
                        String seats = rs.getString("seats");
                        String cost = rs.getString("cost");
                        String Photo = rs.getString("Photo");
                        ViewPackage caption = new ViewPackage(this.Apcks);
                        caption.setPid(Pid);
                        caption.setPName(PName);
                        caption.setorigin(origin);
                        caption.setdestination(destination);
                        caption.setdeparture(departure);
                        caption.setarrival(arrival);
                        caption.setseats(seats);
                        caption.setcost(cost);
                        caption.setimage(Photo);
                        this.Apcks.pnlpackages.add(caption);
                    }
                } else {
                    this.Apcks.pnlpackages.removeAll();
                }
                if (this.Apcks != null) {
                    this.Apcks.pnlpackages.repaint();
                    this.Apcks.pnlpackages.validate();
                }
            } else {
                this.Apcks.pnlpackages.removeAll();
                String query = "Select * from packages where Concat(pname, origin, destination, departure, arrival, cost) like '%" + search + "%'";
                ResultSet rs = LoginPage.db.getResultSet(query);
                if (this.Apcks != null) {
                    while (rs.next()) {
                        int Pid = rs.getInt("Pid");
                        String PName = rs.getString("PName");
                        String origin = rs.getString("origin");
                        String destination = rs.getString("destination");
                        String departure = rs.getString("departure");
                        String arrival = rs.getString("arrival");
                        String seats = rs.getString("seats");
                        String cost = rs.getString("cost");
                        String Photo = rs.getString("Photo");
                        ViewPackage caption = new ViewPackage(this.Apcks);
                        caption.setPid(Pid);
                        caption.setPName(PName);
                        caption.setorigin(origin);
                        caption.setdestination(destination);
                        caption.setdeparture(departure);
                        caption.setarrival(arrival);
                        caption.setseats(seats);
                        caption.setcost(cost);
                        caption.setimage(Photo);
                        this.Apcks.pnlpackages.add(caption);
                    }
                } else {
                    this.Apcks.pnlpackages.removeAll();
                }
                if (this.Apcks != null) {
                    this.Apcks.pnlpackages.repaint();
                    this.Apcks.pnlpackages.validate();
                }
            }
        } catch (Exception e) {
        }
    }

    public void getofferpkgs(String search) {
        try {
            if (search.equals("")) {
            this.Apcks.pnlpackages.removeAll();

//            String qury = "select * from user_details where username = '" + finalUser + "'";
//            ResultSet rr = LoginPage.db.getResultSet(qury);
//            if (rr.next()) {
//                OfferPackage.offeremail = rr.getString("email");
                this.Apcks.pnlpackages.add(message);
                message.setText("User Eligible for offer : " +finalUser);
                message.setHorizontalAlignment(JTextField.CENTER);
                message.setForeground(Color.BLACK);

                String query = "select * from packages"; 
                ResultSet rs = LoginPage.db.getResultSet(query);
                if (this.Apcks != null) {
                    while (rs.next()) {
                        int Pid = rs.getInt("Pid");
                        String PName = rs.getString("PName");
                        String origin = rs.getString("origin");
                        String destination = rs.getString("destination");
                        String departure = rs.getString("departure");
                        String arrival = rs.getString("arrival");
                        String seats = rs.getString("seats");
                        String cost = rs.getString("cost");
                        String Photo = rs.getString("Photo");
                        OfferPackage caption = new OfferPackage(this.Apcks);
                        caption.setPid(Pid);
                        caption.setPName(PName);
                        caption.setorigin(origin);
                        caption.setdestination(destination);
                        caption.setdeparture(departure);
                        caption.setarrival(arrival);
                        caption.setseats(seats);
                        caption.setcost(cost);
                        caption.setimage(Photo);
                        this.Apcks.pnlpackages.add(caption);
                    }
                } else {
                    this.Apcks.pnlpackages.removeAll();
                }
                if (this.Apcks != null) {
                    this.Apcks.pnlpackages.repaint();
                    this.Apcks.pnlpackages.validate();
                }
//            }
            }else{
            this.Apcks.pnlpackages.removeAll();
//            String qury = "select * from user_details where username = '" + finalUser + "'";
//            ResultSet rr = LoginPage.db.getResultSet(qury);
//            if (rr.next()) {
//                OfferPackage.offeremail = rr.getString("email");
                this.Apcks.pnlpackages.add(message);
                message.setText("User Eligible for offer : " + finalUser);
                message.setHorizontalAlignment(JTextField.CENTER);
                message.setForeground(Color.BLACK);

                String query = "Select * from packages where Concat(pname, origin, destination, departure, arrival, cost) like '%" + search + "%'";
                ResultSet rs = LoginPage.db.getResultSet(query);
                if (this.Apcks != null) {
                    while (rs.next()) {
                        int Pid = rs.getInt("Pid");
                        String PName = rs.getString("PName");
                        String origin = rs.getString("origin");
                        String destination = rs.getString("destination");
                        String departure = rs.getString("departure");
                        String arrival = rs.getString("arrival");
                        String seats = rs.getString("seats");
                        String cost = rs.getString("cost");
                        String Photo = rs.getString("Photo");
                        OfferPackage caption = new OfferPackage(this.Apcks);
                        caption.setPid(Pid);
                        caption.setPName(PName);
                        caption.setorigin(origin);
                        caption.setdestination(destination);
                        caption.setdeparture(departure);
                        caption.setarrival(arrival);
                        caption.setseats(seats);
                        caption.setcost(cost);
                        caption.setimage(Photo);
                        this.Apcks.pnlpackages.add(caption);
                    }
                } else {
                    this.Apcks.pnlpackages.removeAll();
                }
                if (this.Apcks != null) {
                    this.Apcks.pnlpackages.repaint();
                    this.Apcks.pnlpackages.validate();
                }
//            }
            }
        } catch (Exception e) {
        }
    }
}

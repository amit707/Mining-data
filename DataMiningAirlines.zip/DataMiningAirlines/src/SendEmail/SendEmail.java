/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SendEmail;

/**
 *
 * @author kp
 */
import java.util.*;
import javax.activation.*;
import javax.mail.*;
import javax.mail.internet.*;

public class SendEmail {

    private static String femail = "airlinespvppcoe@gmail.com";
    private static String pass = "Airline@123";
    boolean done = false;
    
    public static void main(String args[]){
      new SendEmail("airlinememo@gmail.com","hi","welcome", "E:/Final Year Project/DataMiningAirlines/Images/1download.jpg");
    }

    public SendEmail(String toemail, String Subject, String Greeting, String Attachment) {

        String to = toemail;
        String subject = Subject;
        String messageText = Greeting;
        boolean sessionDebug = false;

        Session session = createSmtpSession();
// Set debug on the Session so we can see what is going on
// Passing false will not echo debug info, and passing true will.        
        session.setDebug(sessionDebug);
        try {
// Instantiate a new MimeMessage and fill it with the required information.
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(femail));
            InternetAddress[] address = {new InternetAddress(to)};
            msg.setRecipients(Message.RecipientType.TO, address);
            msg.setSubject(subject);
            msg.setSentDate(new Date());
// Hand the message to the default transport service for delivery.
            MimeBodyPart messagePart = new MimeBodyPart();
            messagePart.setContent(messageText, "text/html"); //5
            //
            // Set the email attachment file
            //
            MimeBodyPart attachmentPart = new MimeBodyPart();
            FileDataSource fileDataSource = new FileDataSource(Attachment) {
                @Override
                public String getContentType() {
                    return "application/octet-stream";
                }
            };
            attachmentPart.setDataHandler(new DataHandler(fileDataSource));
            attachmentPart.setFileName(fileDataSource.getName());

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messagePart);
            multipart.addBodyPart(attachmentPart);
            msg.setContent(multipart);
            Transport.send(msg);
            System.out.println("Email Send Successfully.!!!");
            done = true;
        } catch (MessagingException mex) {
            System.out.println("Email does not Send.!!!");
            done = false;
        }
    }
    //===========================================================================

    public static Session createSmtpSession() {
        final Properties props = new Properties();
        props.setProperty("mail.smtp.host", "smtp.gmail.com");
        props.setProperty("mail.smtp.auth", "true");
        props.setProperty("mail.smtp.port", "" + 587);
        props.setProperty("mail.smtp.starttls.enable", "true");

        return Session.getInstance(props, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(femail, pass);
            }
        });
    }
}

package kmeans;

import Login.LoginPage;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;

public class k_Cluster {

    public static ArrayList<String> user = new ArrayList<>();

    public static ArrayList<String> Firstuser = new ArrayList<>();
    public static ArrayList<String> Secounduser = new ArrayList<>();
    public static ArrayList<String> Thirduser = new ArrayList<>();

    public static HashMap<String, Integer> map = new HashMap();

    public static void main(String args[]) {
        cluster();
        for (String user1 : user) {
            clusterCreator(user1);
        }
        System.out.println(map);
        MaxFinder();
    }

    public static void Stater() {
        cluster();
        if (user.size()>0) {
            for (String user1 : user) {
                clusterCreator(user1);
            }
            System.out.println(map);
            MaxFinder();
        }
    }

    public static void cluster() {
        user.clear();
        user.clone();
        map.clear();
        map.clone();
        Firstuser.clear();
        Firstuser.clone();
        Secounduser.clear();
        Secounduser.clone();
        Thirduser.clear();
        Thirduser.clone();
        try {
            String sql = "SELECT DISTINCT username from transaction";
            ResultSet rs = LoginPage.db.getResultSet(sql);
            while (rs.next()) {
                user.add(rs.getString(1));
            }
            System.out.println(user);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void clusterCreator(String user) {
        try {
            int i = 0;
            String sql = "SELECT * from transaction where username = '" + user
                    + "' ";
            ResultSet rs = LoginPage.db.getResultSet(sql);
            while (rs.next()) {
                i++;
            }
            System.out.println(user);
            map.put(user, i);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void MaxFinder() {
        int maxValue = Collections.max(map.values());
        System.out.println("maxValue: " + maxValue);

        int first = maxValue / 3;
        System.out.println("first :" + first);

        for (Entry<String, Integer> entry : map.entrySet()) {
            if (entry.getValue() <= first) {
                System.out.println(entry.getKey());
                Firstuser.add(entry.getKey());
            }
        }

        int secound = first + first;

        for (Entry<String, Integer> entry : map.entrySet()) {
            if (entry.getValue() > first && entry.getValue() <= secound) {
                System.out.println(entry.getKey());
                Secounduser.add(entry.getKey());
            }
        }

        for (Entry<String, Integer> entry : map.entrySet()) {
            if (entry.getValue() > secound) {
                System.out.println(entry.getKey());
                Thirduser.add(entry.getKey());
            }
        }
        System.out.println("Firstuser :" + Firstuser);
        System.out.println("Secounduser :" + Secounduser);
        System.out.println("Thirduser :" + Thirduser);
    }
}

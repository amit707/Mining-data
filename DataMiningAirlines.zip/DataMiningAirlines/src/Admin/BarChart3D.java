/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BarChart3D extends javax.swing.JFrame {

    public BarChart3D(final String title) {
        super(title);

        final CategoryDataset dataset = createDataset();
        final JFreeChart chart = createChart(dataset);
        final ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(1350, 650));
        setContentPane(chartPanel);
    }

    // ****************************************************************************
    // * JFREECHART DEVELOPER GUIDE                                               *
    // * The JFreeChart Developer Guide, written by David Gilbert, is available   *
    // * to purchase from Object Refinery Limited:                                *
    // *                                                                          *
    // * http://www.java2s.com/Code/Java/Chart/JFreeChartBarChart3DDemo3withitemlabelsdisplayed.htm                   *
    // *                                                                          *
    // * Sales are used to provide funding for the JFreeChart project - please    * 
    // * support us so that we can continue developing free software.             *
    // ****************************************************************************
    private CategoryDataset createDataset() {
        final DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        
        String content = Dates.graphdata;
        String[] divisions = content.split(",");
        for (int t = 0; t < divisions.length; t++) {
            for (int t1 = 0; t1 < 1; t1++) {
                String[] tagid = divisions[t].split("-");
                String time = tagid[0].replaceAll(" ", "");
                String cond = tagid[1].replaceAll(" ", "");
                String tag = tagid[2].replaceAll(" ", "");

                dataset.addValue(Double.valueOf(time), cond, tag);
                System.err.println(Double.valueOf(time) + "  " + cond + "  " + tag);
            }
        }
        return dataset;
    }

    private JFreeChart createChart(final CategoryDataset dataset) {
        final JFreeChart chart = ChartFactory.createBarChart3D(
                "", // chart title
                "Tourist Spots", // domain axis label
                "Total Packages sold", // range axis label
                dataset, // data
                PlotOrientation.VERTICAL, // orientation
                true, // include legend
                true, // tooltips
                false // urls
        );
        final CategoryPlot plot = chart.getCategoryPlot();
        final CategoryAxis axis = plot.getDomainAxis();
        axis.setCategoryLabelPositions(
                CategoryLabelPositions.createUpRotationLabelPositions(Math.PI / 8.0));
        return chart;
    }

    public static void main(final String[] args) {

        BarChart3D demo111 = new BarChart3D("");
        demo111.pack();
        RefineryUtilities.centerFrameOnScreen(demo111);
        demo111.setVisible(true);
    }
}

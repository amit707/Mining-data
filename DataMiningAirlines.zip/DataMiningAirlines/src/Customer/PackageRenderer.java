/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Customer;

import Login.LoginPage;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.sql.ResultSet;
import javax.swing.JTextField;

/**
 *
 * @author test
 */
public class PackageRenderer {

    Packages pcks;

    public PackageRenderer(Packages pcks) {
        this.pcks = pcks;
        message.setFont(new Font("Serif", Font.ITALIC, 24));
        message.setPreferredSize(new Dimension(770, 40));
        message.setEditable(false);

        offermessage.setFont(new Font("Serif", Font.ITALIC, 24));
        offermessage.setPreferredSize(new Dimension(770, 40));
        offermessage.setEditable(false);
    }
    public javax.swing.JTextField message = new javax.swing.JTextField();
    public javax.swing.JTextField offermessage = new javax.swing.JTextField();
    /*
     * Getting Packages  
     * 
     */

    public void getpkgs(String search) {
        try {
            if (search.equals("")) {
                this.pcks.pnlpackages.removeAll();
                String query = "";
                if (LoginPage.salary.equals("very low") || LoginPage.salary.equals("low")) {
                    query = "select * from packages ORDER BY cost ASC";
                } else if (LoginPage.salary.equals("very high") || LoginPage.salary.equals("high")) {
                    query = "select * from packages ORDER BY cost DESC";
                } else {
                    query = "select * from packages";
                }
                ResultSet rs = LoginPage.db.getResultSet(query);
                if (this.pcks != null) {
                    while (rs.next()) {
                        int Pid = rs.getInt("Pid");
                        String PName = rs.getString("PName");
                        String origin = rs.getString("origin");
                        String destination = rs.getString("destination");
                        String departure = rs.getString("departure");
                        String arrival = rs.getString("arrival");
                        String seats = rs.getString("seats");
                        String cost = rs.getString("cost");
                        String Photo = rs.getString("Photo");
                        Newpackage caption = new Newpackage(this.pcks);
                        caption.setPid(Pid);
                        caption.setPName(PName);
                        caption.setorigin(origin);
                        caption.setdestination(destination);
                        caption.setdeparture(departure);
                        caption.setarrival(arrival);
                        caption.setseats(seats);
                        caption.setcost(cost);
                        caption.setimage(Photo);
                        this.pcks.pnlpackages.add(caption);
                    }
                } else {
                    this.pcks.pnlpackages.removeAll();
                }
                if (this.pcks != null) {
                    this.pcks.pnlpackages.repaint();
                    this.pcks.pnlpackages.validate();
                }
            } else {
                this.pcks.pnlpackages.removeAll();
                String query = "Select * from packages where Concat(pname, origin, destination, departure, arrival, cost) like '%" + search + "%'";
                ResultSet rs = LoginPage.db.getResultSet(query);
                if (this.pcks != null) {
                    while (rs.next()) {
                        int Pid = rs.getInt("Pid");
                        String PName = rs.getString("PName");
                        String origin = rs.getString("origin");
                        String destination = rs.getString("destination");
                        String departure = rs.getString("departure");
                        String arrival = rs.getString("arrival");
                        String seats = rs.getString("seats");
                        String cost = rs.getString("cost");
                        String Photo = rs.getString("Photo");
                        Newpackage caption = new Newpackage(this.pcks);
                        caption.setPid(Pid);
                        caption.setPName(PName);
                        caption.setorigin(origin);
                        caption.setdestination(destination);
                        caption.setdeparture(departure);
                        caption.setarrival(arrival);
                        caption.setseats(seats);
                        caption.setcost(cost);
                        caption.setimage(Photo);
                        this.pcks.pnlpackages.add(caption);
                    }
                } else {
                    this.pcks.pnlpackages.removeAll();
                }
                if (this.pcks != null) {
                    this.pcks.pnlpackages.repaint();
                    this.pcks.pnlpackages.validate();
                }
            }
        } catch (Exception e) {
        }
    }

    public void getrecompkgs(int pid) {
        try {
            this.pcks.pnlpackages1.removeAll();
            String[] freqtpkgs = null;
            String pids = "";
            try {
                String sql1 = "select * from frequentitems";
                ResultSet rs1 = LoginPage.db.getResultSet(sql1);
                if (rs1.next()) {
                    pids = rs1.getString(1);
                    freqtpkgs = pids.split(",");
                }
            } catch (Exception e) {
                System.out.print(e);
            }

            String viewquery = "select * from offer where username='" + LoginPage.usrname + "'";
            ResultSet rs = LoginPage.db.getResultSet(viewquery);
            if (rs.next()) {
                this.pcks.pnlpackages1.add(offermessage);
                offermessage.setText("Offer From Indian Atrlines");
                offermessage.setHorizontalAlignment(JTextField.CENTER);
                offermessage.setForeground(Color.GREEN);

                String Discount = rs.getString("discount");

                viewquery = "select * from packages where pid=" + rs.getInt("pid") + "";
                rs = LoginPage.db.getResultSet(viewquery);
                if (this.pcks != null) {
                    if (rs.next()) {
                        int Pid = rs.getInt("Pid");
                        String PName = rs.getString("PName");
                        String origin = rs.getString("origin");
                        String destination = rs.getString("destination");
                        String departure = rs.getString("departure");
                        String arrival = rs.getString("arrival");
                        String seats = rs.getString("seats");
                        String Photo = rs.getString("Photo");
                        BookNewpackage caption = new BookNewpackage(this.pcks);
                        caption.setPid(Pid);
                        caption.setPName(PName);
                        caption.setorigin(origin);
                        caption.setdestination(destination);
                        caption.setdeparture(departure);
                        caption.setarrival(arrival);
                        caption.setseats(seats);
                        caption.setcost("with discount Rs." + Discount);
                        caption.setimage(Photo);
                        this.pcks.pnlpackages1.add(caption);
                    }
                }

            }

            viewquery = "select * from packages where pid=" + pid + "";
            rs = LoginPage.db.getResultSet(viewquery);
            if (this.pcks != null) {
                if (rs.next()) {
                    int Pid = rs.getInt("Pid");
                    String PName = rs.getString("PName");
                    String origin = rs.getString("origin");
                    String destination = rs.getString("destination");
                    String departure = rs.getString("departure");
                    String arrival = rs.getString("arrival");
                    String seats = rs.getString("seats");
                    String cost = rs.getString("cost");
                    String Photo = rs.getString("Photo");
                    BookNewpackage caption = new BookNewpackage(this.pcks);
                    caption.setPid(Pid);
                    caption.setPName(PName);
                    caption.setorigin(origin);
                    caption.setdestination(destination);
                    caption.setdeparture(departure);
                    caption.setarrival(arrival);
                    caption.setseats(seats);
                    caption.setcost(cost);
                    caption.setimage(Photo);
                    this.pcks.pnlpackages1.add(caption);
                }
            } else {
                this.pcks.pnlpackages1.removeAll();
            }
            if (this.pcks != null) {
                this.pcks.pnlpackages1.repaint();
                this.pcks.pnlpackages1.validate();
            }
            if (freqtpkgs != null) {
                this.pcks.pnlpackages1.add(message);
                message.setText("People Also Search for these Packages");
                message.setHorizontalAlignment(JTextField.CENTER);
                message.setForeground(Color.GREEN);

                for (String pkg : freqtpkgs) {
                    if (!pkg.equals(pid + "")) {
                        String query = "select * from packages where pid=" + pkg + "";
                        rs = LoginPage.db.getResultSet(query);
                        if (this.pcks != null) {
                            if (rs.next()) {
                                int Pid = rs.getInt("Pid");
                                String PName = rs.getString("PName");
                                String origin = rs.getString("origin");
                                String destination = rs.getString("destination");
                                String departure = rs.getString("departure");
                                String arrival = rs.getString("arrival");
                                String seats = rs.getString("seats");
                                String cost = rs.getString("cost");
                                String Photo = rs.getString("Photo");
                                BookNewpackage caption = new BookNewpackage(this.pcks);
                                caption.setPid(Pid);
                                caption.setPName(PName);
                                caption.setorigin(origin);
                                caption.setdestination(destination);
                                caption.setdeparture(departure);
                                caption.setarrival(arrival);
                                caption.setseats(seats);
                                caption.setcost(cost);
                                caption.setimage(Photo);
                                this.pcks.pnlpackages1.add(caption);
                            }
                        } else {
                            this.pcks.pnlpackages1.removeAll();
                        }
                        if (this.pcks != null) {
                            this.pcks.pnlpackages1.repaint();
                            this.pcks.pnlpackages1.validate();
                        }
                    }
                }
            }
        } catch (Exception e) {
        }
    }
}

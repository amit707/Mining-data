package Admin;

import Login.LoginPage;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

public class GetDetails {

    public static boolean isPhoneNumberValid(String phoneNumber) {
        boolean isValid = false;
        
        String expression = "[789]{1}[0-9]{9}";//this to validate only 10 digit numbers
        CharSequence inputStr = phoneNumber;
        Pattern pattern = Pattern.compile(expression);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }
    public static boolean isEmailValid(String email) {
        boolean isValid = false;

        //Initialize reg ex for email.  
        String expression = "[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}";
        CharSequence inputStr = email;
        //Make the comparison case-insensitive.  
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }
    
    public static int id(String tablename){
        int id = 0;
        try {
            String query = "select max(id) from "+tablename;
            ResultSet rs = LoginPage.db.getResultSet(query);
            if (rs.next()) {
                String pckid = rs.getString(1);
                if (pckid != null) {
                    id = Integer.parseInt(pckid);
                }
            }
            id++;
        } catch (SQLException ex) {
            Logger.getLogger(GetDetails.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }
    
 public static int AgeCalculate(int y,int m,int d)
  {
      Calendar now = Calendar.getInstance();
        Calendar dob = Calendar.getInstance();
        
        dob.set(y, m, d);
        if (!dob.after(now)) {
            AddPackage.txtDepart.setText("");
            JOptionPane.showMessageDialog(null,"Please dont select past date","Error", JOptionPane.ERROR_MESSAGE);
        }
        else
        {
        AddPackage.txtDepart.setText("");
        JOptionPane.showMessageDialog(null,"Please dont select past date","Error", JOptionPane.ERROR_MESSAGE);
        }
        
        int year1 = now.get(Calendar.YEAR);
        int year2 = dob.get(Calendar.YEAR);
        int age = year1 - year2;
        int month1 = now.get(Calendar.MONTH);
        int month2 = dob.get(Calendar.MONTH);
        
        if (month2 > month1) {
            age--;
        } else if (month1 == month2) {
            int day1 = now.get(Calendar.DAY_OF_MONTH);
            int day2 = dob.get(Calendar.DAY_OF_MONTH);
            if (day2 > day1) {
                age--;
            }
        }
        //System.out.println("Age is : "+age);
        return age;
  }
}
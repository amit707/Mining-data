/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SendEmail;

/**
 *
 * @author Administrator
 */
public class sendEmailThread implements Runnable {

    String toemail = "";
    String Subject = "";
    String Greeting = "";
    String Attachment = "";

    public sendEmailThread(String temail, String sbject, String greeting, String attachement) {
        toemail = temail;
        Subject = sbject;
        Greeting = greeting;
        Attachment = attachement;
    }

    @Override
    public void run() {
        try {
            SendEmail smp = new SendEmail(toemail, Subject, Greeting, Attachment);
        } catch (Exception e) {
        }
    }
}
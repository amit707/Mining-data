package ItemFreqFinder;

import java.sql.ResultSet;
import java.util.ArrayList;
import AprioriAlgo.*;
import Login.LoginPage;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ItemFreq {

    public static ArrayList<String> id = new ArrayList<>();
    public static ArrayList<String> finalfreq = new ArrayList<>();

    public static void ItemFreq() {
        try {
            id = new ArrayList<>();
            String query = "SELECT DISTINCT username from transaction";
            ResultSet rx = LoginPage.db.getResultSet(query);
            while (rx.next()) {
                String user = rx.getString(1);
                try {
                    String sql = "select pid from transaction where username='" + user + "'";
                    String pids = "";
                    int i = 0;
                    ResultSet rs = LoginPage.db.getResultSet(sql);
                    while (rs.next()) {
                        try {
                            if (i == 0) {
                                i = 1;
                                pids = String.valueOf(rs.getInt(1));
                            } else {
                                pids = pids + " " + String.valueOf(rs.getInt(1));
                            }
                        } catch (Exception e) {
                            System.out.print(e);
                        }
                    }

                    ItemFreq fre = new ItemFreq();
                    fre.id.add(pids);
                    rs.close();

                } catch (Exception e) {
                    System.out.print(e);
                }
            }
            if(id.size()>0){
            EditFile file = new EditFile();
            file.writer(id);
            Apriori apri = new Apriori();
            int freq = finalfreq.size();
            System.out.println("Final output : " + finalfreq.get(freq - 1));
            String Finalfrequent = finalfreq.get(freq - 1).replaceAll("\\[|\\]", "").replaceAll(" ", "");
            System.out.println(Finalfrequent);

            query = "select * from frequentitems";
            ResultSet rs = LoginPage.db.getResultSet(query);
            if (rs.next()) {
                query = "Update frequentitems set pids = '" + Finalfrequent + "'";
                LoginPage.db.getUpdate(query);
            } else {
                query = "insert into frequentitems values('" + Finalfrequent + "')";
                LoginPage.db.getUpdate(query);
            }
            }
        } catch (SQLException ex) {
            Logger.getLogger(ItemFreq.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

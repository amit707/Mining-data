package pso;

import Login.LoginPage;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PSO {

    public static int Total = 0;
    public static String finalUser = "";
    public static int TotalTransaction = 0;
    public static int AvgTranscrionCost;
    public static ArrayList<String> DISTINCTuser = new ArrayList<>();
    public static HashMap<String, Integer> map = new HashMap();
    public static HashMap<String, Integer> Finalmap = new HashMap();

    public static void main(String args[]) {
        map.clear();
        map.clone();
        DISTINCTuser.clear();
        DISTINCTuser.clone();
        pso();
        UserIdentifyer();

        for (String DISTINCTuser1 : DISTINCTuser) {
            FrequncyOfCrosAvg(DISTINCTuser1);
        }
        System.out.println(map);
        FINAL();
    }

    public static String psostart() {
        map.clear();
        map.clone();
        DISTINCTuser.clear();
        DISTINCTuser.clone();
        Finalmap.clear();
        Finalmap.clone();
        pso();
        UserIdentifyer();

        for (String DISTINCTuser1 : DISTINCTuser) {
            FrequncyOfCrosAvg(DISTINCTuser1);
        }
        System.out.println(map);
        if (map.size() > 0) {
            FINAL();
        }
        return finalUser;
    }

    public static void pso() {
        try {
            String sql = "SELECT * from transaction";
            ResultSet rs = LoginPage.db.getResultSet(sql);
            while (rs.next()) {
                Total = Total + Integer.valueOf(rs.getString("cost"));
                TotalTransaction++;
            }
        } catch (SQLException | NumberFormatException e) {
            System.out.println(e);
        }
        if (Total > 0 && TotalTransaction > 0) {
            System.out.println("Total: " + Total);
            System.out.println("TotalTransaction: " + TotalTransaction);
            AvgTranscrionCost = Total / TotalTransaction;
            System.out.println("AvgTranscrionCost: " + AvgTranscrionCost);
        }
    }

    public static void UserIdentifyer() {
        try {
            String sql = "SELECT DISTINCT username from transaction";
            ResultSet rs = LoginPage.db.getResultSet(sql);
            while (rs.next()) {
                DISTINCTuser.add(rs.getString(1));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println(DISTINCTuser);
    }

    public static void FrequncyOfCrosAvg(String user) {
        int count = 0;
        try {
            String sql = "SELECT cost from transaction where username='" + user
                    + "'";
            ResultSet rs = LoginPage.db.getResultSet(sql);
            while (rs.next()) {
                int cost = Integer.valueOf(rs.getString("cost"));
                if (cost > AvgTranscrionCost) {
                    count++;
                }
            }
        } catch (SQLException | NumberFormatException e) {
            System.out.println(e);
        }
        map.put(user, count);
    }

    public static void FINAL() {
        ArrayList<String> freq = new ArrayList<>();
        int maxValue = Collections.max(map.values());
        System.out.println("maxValue: " + maxValue);

        for (Entry<String, Integer> entry : map.entrySet()) {
            if (entry.getValue() == maxValue) {
                System.out.println(entry.getKey());
                freq.add(entry.getKey());
            }
        }
        System.out.println("freq: " + freq);

        if (freq.size() > 0) {

            for (String freq1 : freq) {
                try {
                    String sql = "SELECT date from transaction where username='" + freq1 + "'";
                    ResultSet rs = LoginPage.db.getResultSet(sql);
                    while (rs.next()) {
                        SimpleDateFormat myFormat = new SimpleDateFormat("dd-MM-yyyy");
                        String inputString1 = rs.getString(1);
                        Date date = new Date();
                        String inputString2 = myFormat.format(date);
                        try {
                            Date date1 = (Date) myFormat.parse(inputString1);
                            Date date2 = (Date) myFormat.parse(inputString2);
                            long diff = date2.getTime() - date1.getTime();
                            // System.out.println ("Days: " +
                            // TimeUnit.DAYS.convert(diff,
                            // TimeUnit.MILLISECONDS));
                            Finalmap.put(freq1, (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
            System.out.println("Finalmap: " + Finalmap);

//            int min = Collections.min(Finalmap.values());
//            System.out.println("min: " + min);
//            for (Entry<String, Integer> entry : Finalmap.entrySet()) {
//                if (entry.getValue() == min) {
//                    finalUser = entry.getKey();
//                }
//            }
            finalUser = FinalHashmapSort(Finalmap);
            finalUser = finalUser.substring(1);
            System.out.println("User Eligible for offer : " + finalUser);
        }
    }

    public static String FinalHashmapSort(HashMap<String, Integer> finalmap) {
        String FinalHashmap = "";

        Set<Entry<String, Integer>> set = finalmap.entrySet();
        List<Entry<String, Integer>> list = new ArrayList<>(set);
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> o1,
                    Map.Entry<String, Integer> o2) {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });

        int i = 0;

        for (Entry<String, Integer> entry : list) {
            if (i < 5) {
                FinalHashmap += "," + entry.getKey();
                i++;
            }
        }
        return FinalHashmap;
    }
}
